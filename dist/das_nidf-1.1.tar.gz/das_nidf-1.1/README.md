# DAS_NIDF - Distributed Acoustic Sensing Data Visualization

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://python.org)  
[![PyPI Version](https://img.shields.io/pypi/v/das-nidf.svg)](https://pypi.org/project/das-nidf/)  
[![Downloads](https://img.shields.io/pypi/dm/das-nidf.svg)](https://pypi.org/project/das-nidf/)  

---

## Overview

**DAS_NIDF** is a comprehensive Python library for visualizing and analyzing **Distributed Acoustic Sensing (DAS)** data. It provides interactive, high-performance visualization tools using **Holoviews + Datashader**, capable of handling billions of data points.

Developed for Núcleo Interdisciplinar de Dinâmica dos Fluidos (NIDF).

---

## Features

- **Interactive Waterfall Plots** - Real-time zoom, pan, and hover  
- **Spectrogram Analysis** - Integrated band power maps  
- **Frequency-Wavenumber (f-k) Analysis** - 2D FFT for wavefield analysis  
- **ROI Analysis** - Region of Interest extraction and visualization  
- **Customizable Colormaps** - Viridis, Plasma, and more  
- **High Performance** - Datashader rendering for large datasets  
- **Interactive Dashboard** - All plots combined in a single HTML page  
- **Complete Processing Pipeline** - From HDF5 to visualization  

---

## Installation

### From PyPI (recommended)

```bash
pip install das-nidf
```

### From source

```bash
git clone https://github.com/MSL01/DAS-PROCESSING-AND-VISUALIZATION.git
cd DAS-PROCESSING-AND-VISUALIZATION
pip install -e .
```

---

## Dependencies

Automatically installed with the package:

- numpy >= 1.20.0  
- scipy >= 1.7.0  
- h5py >= 3.0.0  
- holoviews >= 1.15.0  
- datashader >= 0.14.0  
- bokeh >= 2.4.0  
- scikit-image >= 0.19.0  

---

## 🚀 Quick Start

```python
from das_nidf import DASPreprocessor, DASVisualizer

# Initialize preprocessor
preprocessor = DASPreprocessor()

# Process your DAS data (one line!)
X, t, y, fs, dx, num_locs = preprocessor.process_full_pipeline(
    filePath='your_data.h5',
    t_start_cut=5.0,
    t_end_cut=30.0,
    hp_cut=0.1,
    lp_cut=17000,
    remove_dc=True
)

# Create visualizer
visualizer = DASVisualizer(
    X=X.T,  # channels × time
    t=t,
    y=y[:, 0],
    fs=fs,
    dx=dx,
    num_locs=num_locs,
    num_tr=len(t)
)

# Set visualization parameters
params = {
    'startFiber': 420,
    'endFiber': 580,
    'startFiberProfile': 430,
    'endFiberProfile': 482,
    'phase_min': -10.01,
    'phase_max': 10.01,
    'hp_cut': 0.1,
    'lp_cut': 17000,
    'scale_factor': 0.00373,
    'output_name': 'my_analysis'
}

# Generate interactive dashboard
visualizer.run_complete_visualization(params)
```

---

## 📖 Detailed Usage

### 1. Complete Processing Pipeline

The process_full_pipeline method handles:

- Reads HDF5 file  
- Extracts metadata (fs, dx, num_locs)  
- Applies temporal cutting  
- Removes DC mean  
- Applies bandpass filter  

```python
from das_nidf import DASPreprocessor

preprocessor = DASPreprocessor()

X, t, y, fs, dx, num_locs = preprocessor.process_full_pipeline(
    filePath='data.h5',
    t_start_cut=5.0,
    t_end_cut=30.0,
    hp_cut=0.1,
    lp_cut=17000
)
```

---

### 2. Individual Plots

```python
# Figure 1: Time signals with FFT
visualizer.signal_fft_plot(
    chan_view=430,
    chan_view2=482,
    phase_min=-10.01,
    phase_max=10.01,
    hp_cut=0.1,
    lp_cut=17000,
    scale_factor=0.00373,
    output_dir='results'
)

# Figure 2: PSD maps
visualizer.phase_psd_plot(
    hp_cut=0.1,
    lp_cut=17000,
    scale_factor=0.00373,
    phase_min=-10.01,
    phase_max=10.01,
    output_dir='results'
)

# Figure 3: ROI Phase map
visualizer.phase_roi_plot(
    startFiber=420,
    endFiber=580,
    phase_min=-10.01,
    phase_max=10.01,
    output_dir='results'
)

# Figure 4: ROI PSD map
visualizer.psd_roi_plot(
    startFiber=420,
    endFiber=580,
    hp_cut=0.1,
    lp_cut=17000,
    output_dir='results'
)

# Figure 5: F-K analysis
visualizer.k_f_plot(
    startFiber=420,
    endFiber=580,
    scale_factor=0.00373,
    output_dir='results'
)
```

---

## 🌟 Acknowledgments

- HoloViz team for Holoviews and Datashader  
- Bokeh team for interactive visualization  
- NIDF and LPS - UFRJ for research support  
